﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using HelixToolkit.Geometry;
using HelixToolkit.Wpf;


namespace prova
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            this.InitializeComponent();
            Create3DViewPort();
        }

        private void Create3DViewPort()
        {
            // 1. Creiamo la Viewport
            var hVp3D = new HelixViewport3D();

            // 2. Aggiungiamo le luci (fondamentali per vedere l'oggetto)
            hVp3D.Children.Add(new DefaultLights());

            // 3. Creiamo la teiera (il nome corretto è TeapotVisual3D)
            var teaPot = new Teapot();
            hVp3D.Children.Add(teaPot);

            // 4. Invece di AddChild, assegniamo la viewport al contenuto della finestra
            // NOTA: Questo sostituirà qualsiasi cosa tu abbia scritto nel file .xaml
            this.Content = hVp3D;
        }


    }
}